import { Page, Locator } from "@playwright/test";

const commentText = "this is test comment";
const editPostText = "this is edit post comment";

export default class buzzPage {
  readonly page: Page;

  private buzzLink: Locator;
  private firstPostFooter: Locator;
  private deleteToggle: Locator;
  private deleteButton: Locator;
  private verifyCmnt: Locator;
  private deleteConfirmation: Locator;

  constructor(page: Page) {
    this.page = page;

    this.buzzLink = page.locator("span.oxd-main-menu-item--name", {
      hasText: "Buzz",
    });

    this.deleteToggle = page.locator("(//button[@type='button'])[9]");

    this.deleteButton = page.locator(
      "//li[@class='orangehrm-buzz-post-header-config-item'][1]"
    );

    this.firstPostFooter = page.locator(
      "div.orangehrm-buzz-post-footer"
    ).first();

    this.deleteConfirmation = page.locator(
      "//div[@class='orangehrm-modal-footer']/button[2]"
    );

    this.verifyCmnt = page.locator(
      "//p[@class='oxd-text oxd-text--p oxd-text--toast-message oxd-toast-content-text']"
    );
  }

  async delete() {

    await this.buzzLink.click();
    await this.page.waitForTimeout(3000);
    await this.deleteToggle.click();
    await this.deleteButton.click();
    await this.deleteConfirmation.click();
  }
}