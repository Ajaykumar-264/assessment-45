import { Page, Locator } from "@playwright/test";

const HolidayName = "National Holiday123";

export default class LeavePage {
  readonly page: Page;

  private assignBtn: Locator;
  private assignLeaveTab: Locator;
  private leave: Locator;
  private leaveAssignMsg: Locator;

  constructor(page: Page) {
    this.page = page;
    this.leaveAssignMsg = page.locator("//span[text()='Required']");
    this.assignBtn = page.locator("//button[text()=' Assign ']");
    this.assignLeaveTab = page.locator("//a[text()='Assign Leave']");
    this.leave = page.locator("//ul[@class='oxd-main-menu']/li[3]");
  }

  async verifyLeaveField() {
    await this.leave.click();
    await this.assignLeaveTab.click();
    await this.page.waitForLoadState("networkidle");
    await this.assignBtn.click();
  }
}