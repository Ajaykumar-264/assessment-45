import { Page, Locator } from "@playwright/test";
import path from "path";

const filePath = path.resolve(__dirname, "../../CompanyLogo.png");

export default class AdminPage {
  readonly page: Page;

  private localizationBtn: Locator;
  private langDropdown: Locator;
  private logoMsg: Locator;
  private logoInput: Locator;
  private ColorAttribute: Locator;
  private colorInput: Locator;
  private publishBtn: Locator;
  private AdminLink: Locator;
  private crpTab: Locator;
  private primaryColorBtn: Locator;
  private configTab: Locator;
  private option: Locator;
  private langSaveBtn: Locator;
  private optionEng: Locator;

  constructor(page: Page) {
    this.page = page;

    this.langSaveBtn = page.locator("//button[text()=' Save ' or text()=' 儲存 ']");
    this.option = page.locator("//div[@role='listbox']//span[contains(normalize-space(), 'Chinese (Traditional')]");
    this.optionEng = page.locator("//div[@role='listbox']//span[contains(normalize-space(), 'English (United States')]");
    this.langDropdown = page.locator(".oxd-select-text").first();
    this.localizationBtn = page.locator("//a[text()='Localization']");
    this.logoMsg = page.locator("span.oxd-text.oxd-text--span.oxd-input-field-error-message.oxd-input-group__message");
    this.logoInput = page.locator("//input[@type='file']");
    this.publishBtn = page.locator("//button[text()=' Publish ']");
    this.ColorAttribute = page.locator("//div[@class='oxd-color-input-preview']");
    this.primaryColorBtn = page.locator("//div[@class='oxd-color-input oxd-color-input--active']");
    this.crpTab = page.locator("//a[text()='Corporate Branding']");
    this.configTab = page.locator("//span[text()='Configuration ']");
    this.colorInput = page.locator("//input[@class='oxd-input oxd-input--active']");
    this.AdminLink = page.locator("text=Admin");
  }

  async primaryColor() {
    await this.AdminLink.nth(0).click();
    await this.crpTab.click();
    await this.primaryColorBtn.nth(0).click();
    await this.colorInput.nth(1).fill("#826137");
    await this.publishBtn.click();
  }

  async companyLogo() {
    await this.AdminLink.nth(0).click();
    await this.crpTab.click();
    await this.logoInput.nth(0).setInputFiles(filePath);
  }

  async changeLanguage() {
    await this.AdminLink.first().click();
    await this.configTab.click();
    await this.localizationBtn.click();
    await this.langDropdown.click();
    await this.option.waitFor({
      state: "visible",
    });
    await this.option.click();
    await Promise.all([
      //this.page.waitForLoadState("networkidle"),
      this.langSaveBtn.click(),
    ]);
  }
}