import { Page, Locator } from "@playwright/test";

export default class PIMPage {
  readonly page: Page;

  private PIMLink: Locator;
  private empListbutton: Locator;
  private getEmpId: Locator;
  private fillEmpId: Locator;
  private saveButton: Locator;

  constructor(page: Page) {
    this.page = page;

    this.PIMLink = page.locator('//span[text()="PIM"]');
    this.empListbutton = page.locator('//a[text()="Employee List"]');
    this.getEmpId = page.locator("//div[@role='row']/div[2]");
    this.fillEmpId = page.locator(
      "//label[text()='Employee Id']/../following-sibling::div/input");
    this.saveButton = page.locator("//button[text()=' Search ']");
  }

  async verifyEmp(id: string) {
    await this.PIMLink.click();

    await this.empListbutton.click();

    await this.fillEmpId.waitFor({
      state: "visible"
    });
    
    await this.fillEmpId.fill(id);

    await Promise.all([
      this.page.waitForLoadState("networkidle"),
      this.saveButton.click(),
    ]);
  }

  async getEmpList() {
    await this.PIMLink.click();
    await this.empListbutton.click();
    await this.page.waitForLoadState("networkidle");
    return await this.getEmpId.allInnerTexts();
  }
}