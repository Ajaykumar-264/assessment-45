import { Locator, Page } from "@playwright/test";

const data = JSON.parse(JSON.stringify(require("../Data/login.json")));

export class LoginPage {
  readonly page: Page;
  private usernameInput: Locator;
  private passwordInput: Locator;
  private loginButton: Locator;
  private loginErrorMessage: Locator;
  private adminButton: Locator;
  private logOut: Locator;
  private getButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.usernameInput = page.locator(
      "input[name='username']"
    );
    
    this.passwordInput = page.locator(
      "input[name='password']"
    );
    
    this.loginButton = page.locator(
      "button[type='submit']"
    );
    this.loginErrorMessage = page.locator(".oxd-alert-content-text");
    this.adminButton = page.locator('//li[@class="oxd-userdropdown"]');
    this.logOut = page.locator("//ul[@class='oxd-dropdown-menu']/li[4]");
    this.getButton = page.locator("//div[@class='oxd-topbar-body-nav-slot']/button");
  }

  async performLogin() {

    await this.page.waitForLoadState("networkidle");
  
    await this.usernameInput.fill(
      data.ValidLogin.ValidUserName
    );
  
    await this.passwordInput.fill(
      data.ValidLogin.ValidPassword
    );
  
    await this.loginButton.click();
  }

  async performLogOut(): Promise<string> {
    await this.adminButton.click();
    await this.logOut.click();

    await this.page.waitForURL("**/auth/login");

    return this.page.url();
  }

  async getUrl() {
    const [newPage] = await Promise.all([
      this.page.context().waitForEvent("page"),
      this.getButton.click(),
    ]);

    await newPage.waitForLoadState();

    return newPage.url();
    await newPage.close();
  }
}

module.exports = { LoginPage };