import { Locator, Page } from "@playwright/test";
import path from "path";
import fs from "fs";

const filePath = path.resolve(__dirname, "../../TestImage.jpg");
const Path = path.resolve(__dirname, "../../");
const data = JSON.parse(JSON.stringify(require("../Data/TestData.json")));

export class MyInfoPage {
  readonly page: Page;

  private Myinfo: Locator;
  private downloadBtn: Locator;
  private firstName: Locator;
  private midName: Locator;
  private lastName: Locator;
  private saveBtn: Locator;

  public static fileName: string;

  constructor(page: Page) {
    this.page = page;

    this.firstName = page.locator("input.orangehrm-firstname");
this.midName = page.locator("input[name='middleName']");
this.lastName = page.locator("input.orangehrm-lastname");
    this.saveBtn = page.locator(
      "//button[@type='submit' and contains(@class,'oxd-button')]"
    ).first();
    this.downloadBtn = page.locator(
      "//i[contains(@class,'bi-download')]"
    ).first();
    this.Myinfo = page.locator("//span[text()='My Info']");
    
    //this.Myinfo = page.locator("//a[contains(@href,'viewPersonalDetails')]");
    
  }

  async downloadInfo() {

    await this.Myinfo.click();
  
    await this.firstName.waitFor({
      state: "visible",
      timeout: 10000,
    });
  
    // Scroll to bottom of page
    await this.page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
  
    await this.page.waitForTimeout(3000);
  }
  async verifyUser() {

    await this.Myinfo.click();

await this.firstName.waitFor({
  state: "visible",
  timeout: 10000
});
  
    await this.firstName.waitFor({
      state: "visible",
    });
  
    // First Name
    await this.firstName.click();
    await this.firstName.press("Control+A");
    await this.firstName.press("Backspace");
    await this.firstName.type(data.VerifyUser.firstName);
  
    // Middle Name
    await this.midName.click();
    await this.midName.press("Control+A");
    await this.midName.press("Backspace");
    await this.midName.type(data.VerifyUser.midName);
  
    // Last Name
    await this.lastName.click();
    await this.lastName.press("Control+A");
    await this.lastName.press("Backspace");
    await this.lastName.type(data.VerifyUser.lastName);
  
    // console.log(await this.firstName.inputValue());
    // console.log(await this.midName.inputValue());
    // console.log(await this.lastName.inputValue());
  
    await this.saveBtn.click();
  
    await this.page.waitForTimeout(5000);
  }
}