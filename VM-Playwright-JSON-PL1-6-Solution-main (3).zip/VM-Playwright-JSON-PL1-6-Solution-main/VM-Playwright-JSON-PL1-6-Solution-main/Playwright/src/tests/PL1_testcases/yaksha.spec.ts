import { test, expect, Page } from "@playwright/test";
import { LoginPage } from "../../pages/LoginPage";
import AdminPage from "../../pages/AdminPage";
import LeavePage from "../../pages/LeavePage";
import { MyInfoPage } from "../../pages/MyInfoPage";
import BuzzPage from "../../pages/buzzPage";
import PIMPage from "../../pages/PIMpage";
import * as fs from "fs";
import * as path from "path";

const data = JSON.parse(
  JSON.stringify(require("../../Data/TestData.json"))
);

test.describe("Yaksha", () => {
  let loginPage: LoginPage;
  let myinfoPage: MyInfoPage;
  let adminPage: AdminPage;
  let leavePage: LeavePage;
  let buzzPage: BuzzPage;
  let PimPage: PIMPage;

  test.beforeEach(async ({ page }) => {
    await page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

    loginPage = new LoginPage(page);
    myinfoPage = new MyInfoPage(page);
    adminPage = new AdminPage(page);
    leavePage = new LeavePage(page);
    buzzPage = new BuzzPage(page);
    PimPage = new PIMPage(page);

    await loginPage.performLogin();
  });

  test("1_Verify 'Delete Post' Functionality", async ({ page }) => {
    await buzzPage.delete();
    const deleteConfirmText = await page
    .locator("//p[@class='oxd-text oxd-text--p oxd-text--toast-message oxd-toast-content-text']")
    .first()
    .textContent();

    const actualText = await page
    .locator("//p[contains(@class, 'toast-message') and text()='Successfully Deleted']")
    .textContent();

    expect(deleteConfirmText).toContain(actualText);
  });


  test("TS-2 Verify 'Get' help button is functional", async ({context,}) => {
    const url = await loginPage.getUrl();

    expect(context.pages().length).toBeGreaterThanOrEqual(2);
    expect(url).toBeTruthy();
  });


  test("TS-3 Verify List of Reports", async ({ page }) => {
    await PimPage.getEmpList();

    const actualEmpListElement =
    await page.locator("//div[@class='oxd-table-card']//div[2]").allInnerTexts();
    expect(actualEmpListElement.length).toBeGreaterThan(0);
  });


  test("TS-4 Verify Employee List Search functionality", async ({ page }) => {
    await page.locator('//span[text()="PIM"]').click();
    await page.locator('//a[text()="Employee List"]').waitFor({ state: "visible" }); // Ensure the link is visible
    await page.locator('//a[text()="Employee List"]').click();
    await page.waitForTimeout(3000);

    const list1 = await page.locator("//div[@role='row']/div[2]").allInnerTexts();
    expect(list1.length).toBeGreaterThan(0);
    const id = list1.find((text) => text.trim() !== "");
    expect(id).toBeTruthy();
    if (id) {
      await PimPage.verifyEmp(id);
      const result = await page.locator("//div[@role='row']/div[2]").allInnerTexts();
      expect(result.join(" ")).toContain(id);
    } else {
      throw new Error("No valid employee ID found in the list.");
    }
  });

  test("TS-5 Verify Primary Colour of corporate branding could be changed", async ({
    page,
  }) => {
    await adminPage.primaryColor();

    const actualStyle = await page
      .locator("//div[@class='oxd-color-input-preview']")
      .first()
      .getAttribute("style");

    if (actualStyle) {
      expect(actualStyle).toContain("background-color");
    } else {
      throw new Error("actualStyle is null");
    }
  });

  test("TS-6 Verify Client Logo could not be uploaded above 1 mb", async ({
    page,
  }) => {
    await adminPage.companyLogo();

    const actualMessage = await page
      .locator(
        "span.oxd-text.oxd-text--span.oxd-input-field-error-message.oxd-input-group__message"
      )
      .textContent();

    expect(actualMessage?.trim()).toBe(
      "Attachment Size Exceeded"
    );
  });

  test("TS-7 Verify Language change Functionality", async ({
    page,
  }) => {
    await adminPage.changeLanguage();

    const expectedLang =
      "Chinese (Traditional, Taiwan) - 中文（繁體，台灣）";

    const actualLang = await page
      .locator("//div[@class='oxd-select-text-input']")
      .first()
      .textContent();

      expect(actualLang).toContain("Chinese");

    await page
      .locator(
        "//div[@class='oxd-select-text oxd-select-text--active']"
      )
      .first()
      .click();

    await page
      .locator(
        "//div[@role='listbox']//span[contains(normalize-space(), 'English (United States')]"
      )
      .click();

    await page
      .locator("//button[text()=' Save ' or text()=' 儲存 ']")
      .click();
  });

  test("TS-8 Verify Required Field Error in Leaves Tab displays when required field is empty", async ({
    page,
  }) => {
    await leavePage.verifyLeaveField();

    const errorMsg = await page
      .locator("//span[text()='Required']")
      .first()
      .textContent();

      await expect(
        page.locator("//span[text()='Required']").first()).toBeVisible();
  });

  test.skip("TS-9 Verify My info Download Functionality", async () => {
    await myinfoPage.downloadInfo();

    const fileName = MyInfoPage.fileName;

    expect(fileName).toBeTruthy();

    const fileExists = await isFileDownloaded(fileName);

    expect(fileExists).toBe(true);
  });

  test("TS-10 Verify User details could be Updated", async ({
    page,
  }) => {
    await myinfoPage.verifyUser();

    await page.waitForTimeout(5000);

await assertUserDetailsUpdated(page);
  });
});

async function assertUrl(
  actualUrl: string,
  expectedUrl: string
) {
  expect(actualUrl).toBe(expectedUrl);
}

async function assertUserDetailsUpdated(page: Page) {
  await expect(
    page.locator('input[name="firstName"]')
  ).toHaveValue(data.VerifyUser.firstName);

  await expect(
    page.locator('input[name="middleName"]')
  ).toHaveValue(data.VerifyUser.midName);

  await expect(
    page.locator('input[name="lastName"]')
  ).toHaveValue(data.VerifyUser.lastName);
}

async function isFileDownloaded(
  fileName: string,
  directory: string = path.resolve(
    process.cwd(),
    "downloadImage"
  )
): Promise<boolean> {
  const filePath = path.join(directory, fileName);

  try {
    fs.accessSync(filePath);
    return true;
  } catch {
    return false;
  }
}

async function assertSortedListDescending(
  actualList: string[]
) {
  for (let i = 0; i < actualList.length - 1; i++) {
    if (
      actualList[i].localeCompare(actualList[i + 1]) < 0
    ) {
      throw new Error(
        `List is not sorted in descending order`
      );
    }
  }
}

export function expectPrimaryColorStyle(
  actual: string
) {
  expect(actual).toContain(
    "background-color"
  );
}

export async function assertLanuage(
  page: Page,
  actualLang: string
) {
  expect(actualLang.trim()).toBe(
    "Chinese (Traditional, Taiwan) - 中文（繁體，台灣）"
  );
}

async function assertLeaveAssignErrorMessage(
  page: Page,
  ErrorMsg: string
) {
  const locator = page
    .locator("//span[text()='Required']")
    .first();

  await locator.waitFor({ state: "visible" });

  const actualText = await locator.textContent();

  expect(actualText).toBe(ErrorMsg);
}

async function assertSearchedEmpId(
  page: Page,
  expectedEmpId: string
) {
  const displayedEmpId = await page
    .locator(
      "//div[@class='oxd-table-card']//div[@role='cell']"
    )
    .nth(1)
    .textContent();

  expect(displayedEmpId?.trim()).toBe(expectedEmpId);
}
